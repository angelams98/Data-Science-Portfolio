# -*- coding: utf-8 -*-
"""
Report 2
Machine learning course 02450
Group 63
"""

#Import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import (figure, subplot, hist, xlabel, ylim, show, boxplot, xticks, xlabel, ylabel, title, grid, loglog, legend, semilogx)
from sklearn.model_selection import train_test_split, KFold
import string
from sklearn.metrics import confusion_matrix
from toolbox_02450 import rlr_validate
from sklearn import model_selection
import sklearn.linear_model as lm
from sklearn.model_selection import GridSearchCV
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error as mse
from sklearn.dummy import DummyRegressor
from sklearn.metrics import classification_report,accuracy_score,balanced_accuracy_score
from scipy import stats
from scipy import spatial
import scipy.stats as st
from sklearn import tree
from platform import system
from os import getcwd
from toolbox_02450 import windows_graphviz_call
import matplotlib.pyplot as plt
from matplotlib.image import imread
import sklearn

##################################################################################################
##################################################################################################

#PART 1: REGRESSION

##################################################################################################
##################################################################################################




#################################################
#PREPARATION OF THE DATA
#################################################

# reading csv files
data =  pd.read_excel('../Data/dataset.xls')


#Making dummy variables where needed
data = pd.get_dummies(data, columns=['famhist'])


#Remove famhist_Absent column and change the name
data['log_alcohol'] = np.log(data.alcohol+0.1)
data['log_tobacco'] = np.log(data.tobacco+0.01)
data = data.drop(columns=['famhist_Absent','row','obesity','alcohol', 'tobacco', 'age'])
data = data.rename(columns = {'famhist_Present':'famhist'})


#Pop sbp and save attribute names
Y_data = data.pop('sbp')
y =np.array(Y_data)
attributeNames = data.columns
X = data.to_numpy()
np.shape(data)


# Compute values of N, M and C.
N = len(y)
M = len(attributeNames)


# Add offset attribute
X = np.concatenate((np.ones((X.shape[0],1)),X),1)
attributeNames = [u'Offset']+attributeNames
M = M+1


#################################################
#CALCULATION OF RANGE OF H
#################################################


nh = np.arange(1,20)

perc_test=0.3
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=perc_test,shuffle=True, random_state=1236548)
for i in range(len(nh)):
    MLP=MLPRegressor(max_iter=10000, hidden_layer_sizes=nh[i], activation='tanh', solver='lbfgs', alpha=1e-3, random_state=22)
    #fit the training data
    MLP.fit(X_train,y_train)
    
    predictions_train_MLP = MLP.predict(X_train)
    train_error_MLP= mse(y_train, predictions_train_MLP)
    print('Number of hidden neural networks:', nh[i])
    print('Training Error:', round(train_error_MLP,6))
    predictions_test_MLP = MLP.predict(X_test)
    test_error_MLP= mse(y_test, predictions_test_MLP)
    print('Test Error:', round(test_error_MLP,6))
    print('Test error -Train error:', round(test_error_MLP -train_error_MLP,6))
    score_MLP=MLP.score(X_train, y_train) #returns the R^2 score
    print('R^2 returned by the MLP:', round(score_MLP,6))
    print()


#################################################
#CALCULATION OF REGULARIZATION FACTOR
#CROSS-VALIDATION FOR LINEAR REGRESSION, BASELINE, ANN
#################################################

## Crossvalidation
# Create crossvalidation partition for evaluation
K = 10
CV = model_selection.KFold(K, shuffle=True)
best_parameters = []


# Values of lambda
lambdas = np.power(10.,range(-5,9))

# Initialize variables
#T = len(lambdas)
Error_train = np.empty((K,1))
Error_test = np.empty((K,1))
Error_train_rlr = np.empty((K,1))
Error_test_rlr = np.empty((K,1))
Error_train_nofeatures = np.empty((K,1))
Error_test_nofeatures = np.empty((K,1))
Error_train_ann = np.empty((K,1))
Error_test_ann = np.empty((K,1))
w_rlr = np.empty((M,K))
mu = np.empty((K, M-1))
sigma = np.empty((K, M-1))
w_noreg = np.empty((M,K))
score_MLP = np.empty((K,1))

k=0
for train_index, test_index in CV.split(X,y):
    
    # extract training and test set for current CV fold
    X_train = X[train_index]
    y_train = y[train_index]
    X_test = X[test_index]
    y_test = y[test_index]
    internal_cross_validation = 10    
    
    opt_val_err, opt_lambda, mean_w_vs_lambda, train_err_vs_lambda, test_err_vs_lambda = rlr_validate(X_train, y_train, lambdas, internal_cross_validation)
    print(opt_lambda)

    # Standardize outer fold based on training set, and save the mean and standard
    # deviations since they're part of the model (they would be needed for
    # making new predictions) - for brevity we won't always store these in the scripts
    mu[k, :] = np.mean(X_train[:, 1:], 0)
    sigma[k, :] = np.std(X_train[:, 1:], 0)
    
    X_train[:, 1:] = (X_train[:, 1:] - mu[k, :] ) / sigma[k, :] 
    X_test[:, 1:] = (X_test[:, 1:] - mu[k, :] ) / sigma[k, :] 
    
    Xty = X_train.T @ y_train
    XtX = X_train.T @ X_train
    
    # Compute mean squared error without using the input data at all
    Error_train_nofeatures[k] = np.square(y_train-y_train.mean()).sum(axis=0)/y_train.shape[0]
    Error_test_nofeatures[k] = np.square(y_test-y_test.mean()).sum(axis=0)/y_test.shape[0]

    # Estimate weights for the optimal value of lambda, on entire training set
    lambdaI = opt_lambda * np.eye(M)
    lambdaI[0,0] = 0 # Do no regularize the bias term
    w_rlr[:,k] = np.linalg.solve(XtX+lambdaI,Xty).squeeze()
    # Compute mean squared error with regularization with optimal lambda
    Error_train_rlr[k] = np.square(y_train-X_train @ w_rlr[:,k]).sum(axis=0)/y_train.shape[0]
    Error_test_rlr[k] = np.square(y_test-X_test @ w_rlr[:,k]).sum(axis=0)/y_test.shape[0]

    # Estimate weights for unregularized linear regression, on entire training set
    w_noreg[:,k] = np.linalg.solve(XtX,Xty).squeeze()
    # Compute mean squared error without regularization
    Error_train[k] = np.square(y_train-X_train @ w_noreg[:,k]).sum(axis=0)/y_train.shape[0]
    Error_test[k] = np.square(y_test-X_test @ w_noreg[:,k]).sum(axis=0)/y_test.shape[0]
    # OR ALTERNATIVELY: you can use sklearn.linear_model module for linear regression:
    #m = lm.LinearRegression().fit(X_train, y_train)
    #Error_train[k] = np.square(y_train-m.predict(X_train)).sum()/y_train.shape[0]
    #Error_test[k] = np.square(y_test-m.predict(X_test)).sum()/y_test.shape[0]
    
    
    #create the model we want to use
    MLP=MLPRegressor( activation='tanh', solver='lbfgs', alpha=0.001,random_state=22, max_iter = 10000)
    MLP.fit(X_train,y_train)
    #create the dictionary with the hyperparameters we want to tune

    parameters={'hidden_layer_sizes':np.arange(5,12)} #a dictionary with values from 5to N_max
    grid = GridSearchCV(MLP, parameters, scoring='neg_mean_squared_error', cv=CV, n_jobs=-1, return_train_score=True)
    grid.fit(X_train, y_train)
    best_parameters.append(grid.best_params_)
    predictions_train_MLP = MLP.predict(X_train)
    train_error_MLP= mse(y_train, predictions_train_MLP)
    Error_train_ann[k]= train_error_MLP
    predictions_test_MLP = MLP.predict(X_test)
    test_error_MLP= mse(y_test, predictions_test_MLP)
    Error_test_ann[k] = test_error_MLP

    score_MLP=MLP.score(X_train, y_train) #returns the R^2 score


    k+=1

show()
# Display results

print('Regularized linear regression:')
print('- Training error: {0}'.format(Error_train_rlr.mean()))
print('- Test error:     {0}'.format(Error_test_rlr.mean()))
print('- R^2 train:     {0}'.format((Error_train_nofeatures.sum()-Error_train_rlr.sum())/Error_train_nofeatures.sum()))
print('- R^2 test:     {0}\n'.format((Error_test_nofeatures.sum()-Error_test_rlr.sum())/Error_test_nofeatures.sum()))


print('Weights in last fold:')
for m in range(M):
    print('{:>8} {:>8}'.format(attributeNames[m], np.round(w_rlr[m,-1],2)))
    
    
#################################################
#MODEL COMPARISON OF LINEAR REGRESSION, BASELINE, ANN
#################################################

#Reload the data in a different format
X = data.to_numpy()
attributeNames = data.columns
y = X[:,[0]] 
selector = [x for x in range(X.shape[1]) if x != 0]
X[:, selector]

# Compute values of N, M and C.
N = len(y)
M = len(attributeNames)

#Initialize variables
loss=2
K = 10
m = 1
J = 0
r = []
alpha = 0.05
kf = model_selection.KFold(n_splits=K)

for dm in range(m):
    y_true = []
    yhatC = []
    yhatAB = []
    j=0


    for train_index, test_index in kf.split(X):
        X_train, y_train = X[train_index,:], y[train_index]
        X_test, y_test = X[test_index, :], y[test_index]

        #mA --> linear regression
        #mB --> baseline model
        #mC --> neural network
        mA = sklearn.linear_model.LinearRegression().fit(X_train, y_train)   
        dummy_regr = DummyRegressor(strategy="mean")
        mB = dummy_regr.fit(X_train, y_train)
        mC = MLPRegressor(random_state=1).fit(X_train, y_train)
    

        yhatA = mA.predict(X_test)
        yhatB = mB.predict(X_test)[:, np.newaxis]  
        yhatC_temp = mC.predict(X_test)
        yhatC = np.resize(yhatC_temp,(46,1))

        if len(y_test) == 46:
            y_true.append(y_test)
            
        yhatAB.append( np.concatenate([yhatA, yhatB], axis=1) )
        r.append( np.mean( np.abs( yhatA-y_test ) ** loss - np.abs( yhatB-y_test) ** loss ) )


zA = np.abs(y_test - yhatA ) **2     #L2
zB = np.abs(y_test - yhatB ) **2
zC = np.abs(y_test - yhatC ) **2

zAB = zA - zB
zAC = zA - zC
zBC = zB - zC

CI2AB = st.t.interval(1-alpha, len(zAB)-1, loc=np.mean(zAB), scale=st.sem(zAB))  # Confidence interval
CI2AC = st.t.interval(1-alpha, len(zAC)-1, loc=np.mean(zAC), scale=st.sem(zAC))  # Confidence interval
CI2BC = st.t.interval(1-alpha, len(zBC)-1, loc=np.mean(zBC), scale=st.sem(zBC))  # Confidence interval

pAB = 2*st.t.cdf( -np.abs( np.mean(zAB) )/st.sem(zAB), df=len(zAB)-1)  # p-value
pAC = 2*st.t.cdf( -np.abs( np.mean(zAC) )/st.sem(zAC), df=len(zAC)-1)  # p-value
pBC = 2*st.t.cdf( -np.abs( np.mean(zBC) )/st.sem(zBC), df=len(zBC)-1)  # p-value


print('Confidence intervalAB:', CI2AB)
print('Confidence intervalAC:', CI2AC)
print('Confidence intervalBC:', CI2BC)
print('p-value AB', pAB)
print('p-value AC', pAC)
print('p-value BC', pBC)
print(sum(zAB)/len(zAB))
print(sum(zAC)/len(zAC))
print(sum(zBC)/len(zBC))



##################################################################################################
##################################################################################################

#PART 2: CLASSIFICATION

##################################################################################################
##################################################################################################


#################################################
#PREPARATION OF THE DATA
#################################################


# Import data

import numpy as np
import pandas as pd


# reading csv files
df =  pd.read_excel(r'C:\Users\olive\Documents\DTU\4. semester\Machine Learning and Data Mining\Project 2\dataset.xls')

#Making dummy varibales where needed
df = pd.get_dummies(df, columns=['famhist'])
df = df.drop(columns=['famhist_Absent','row'])
df = df.rename(columns={'famhist_Present': 'famhist'})

#Remove age variable from dataset
df.drop('age', inplace=True, axis=1)

#log transform of alcohol and tobacco
df['alcohol']=np.log(df['alcohol']+0.1)
df['tobacco']=np.log(df['tobacco']+0.01)

# Extract class names to python list,
# then encode with integers (dict)
classLabels = list(df['chd'])
classNames = ['noCHD','CHD']

# Extract vector y, convert to NumPy matrix and transpose
y = np.array(df.pop('chd'))

#Normalise all data if needed
def z_score_standardization(series):
    return (series - series.mean()) / series.std()
for col in df.columns:
    df[col] = z_score_standardization(df[col])


# Extract attribute names
attributeNames = list(df.columns)

# Preallocate memory, then extract data to matrix X
X = df.to_numpy()
np.shape(df)

# Compute values of N, M and C.
N = len(y)
M = len(attributeNames)
C = len(classNames)


#%% imports and helper functions
from sklearn import tree
import numpy as np
from sklearn import tree
from platform import system
from os import getcwd
from toolbox_02450 import windows_graphviz_call
import matplotlib.pyplot as plt
from matplotlib.image import imread
import sklearn
from sklearn import model_selection
import sklearn.linear_model as lin
from sklearn.model_selection import KFold

#%% Leave one out cross validation
CV = model_selection.LeaveOneOut()
i=0

# store predictions.
yhat = []
y_true = []
for train_index, test_index in CV.split(X, y):
    print('Crossvalidation fold: {0}/{1}'.format(i+1,N))    
    
    # extract training and test set for current CV fold
    X_train = X[train_index,:]
    y_train = y[train_index]
    X_test = X[test_index,:]
    y_test = y[test_index]

    # Fit classifier and classify the test points (consider 1 to 40 neighbors)
    dy = []
    for l in range (3):
        if l == 0:
            model = tree.DecisionTreeClassifier(criterion='gini', min_impurity_decrease=0.014)
            model.fit(X_train, y_train)     
            y_est = model.predict(X_test)
            
        elif l == 1:
            model = lin.LogisticRegression(penalty='l2',C=1/(5))    
            model.fit(X_train, y_train)     
            y_est = model.predict(X_test)
            
        elif l == 2:
            y_est = np.array([0])
            
        dy.append(y_est)
        # errors[i,l-1] = np.sum(y_est[0]!=y_test[0])
        
    dy = np.stack(dy, axis=1)
    yhat.append(dy)
    y_true.append(y_test)
    i+=1

yhat = np.concatenate(yhat)
y_true = np.concatenate(y_true)
yhat[:,0] # predictions made by first classifier.

# Compute accuracy here.
print(1-sklearn.metrics.accuracy_score(y,yhat[:,0]))
print(1-sklearn.metrics.accuracy_score(y,yhat[:,1]))
print(1-sklearn.metrics.accuracy_score(y,yhat[:,2]))

# Compute the Jeffreys interval
from toolbox_02450 import mcnemar
alpha = 0.05
[thetahat, CI, p] = mcnemar(y_true, yhat[:,1], yhat[:,2], alpha=alpha)

print("theta = theta_A-theta_B point estimate", thetahat, " CI: ", CI, "p-value", p)


# Import data

import numpy as np
import pandas as pd
from sklearn import model_selection
import sklearn.linear_model as lin
from matplotlib.pylab import figure, plot, xlabel, ylabel, legend, ylim, show
import pandas as pd

# reading csv files
df =  pd.read_excel('dataset.xls')

#Making dummy varibales where needed
df = pd.get_dummies(df, columns=['famhist'])
df = df.drop(columns=['famhist_Absent','row'])
df = df.rename(columns={'famhist_Present': 'famhist'})

#Remove age variable from dataset
df.drop('obesity', inplace=True, axis=1)

#log transform of alcohol and tobacco
df['alcohol']=np.log(df['alcohol']+0.1)
df['tobacco']=np.log(df['tobacco']+0.01)

# Extract class names to python list,
# then encode with integers (dict)
classLabels = list(df['chd'])
classNames = ['noCHD','CHD']

# Extract vector y, convert to NumPy matrix and transpose
y = np.array(df.pop('chd'))

#Normalise all data if needed
def z_score_standardization(series):
    return (series - series.mean()) / series.std()
for col in df.columns:
    df[col] = z_score_standardization(df[col])


# Extract attribute names
attributeNames = list(df.columns)

# Preallocate memory, then extract data to matrix X
X = df.to_numpy()
np.shape(df)

# Compute values of N, M and C.
N = len(y)
M = len(attributeNames)
C = len(classNames)


Xtrain, Xtest, ytrain, ytest = model_selection.train_test_split(X,y,test_size=0.3,random_state=9)

model = lin.LogisticRegression(penalty='l2',C=1/(5))
                                                              
model.fit(Xtrain,ytrain)

print(model.coef_)

df = pd.DataFrame()
df['Xtest']=list(Xtest)
df['ytest']=list(ytest)
df = df.sort_values('ytest')
ytest = np.array(df['ytest'])
Xtest_sorted = np.array(df['Xtest'])

for i in range(len(Xtest)):
    if i == 0:
        Xtest = np.array(Xtest_sorted[i])
    else:
        Xtest = np.vstack((Xtest,np.array(Xtest_sorted[i])))


# Classify wine as White/Red (0/1) and assess probabilities
y_est = model.predict(Xtest)
y_est_prob = model.predict_proba(Xtest)[:, 0] 


# Evaluate the probability of x being a white wine (class=0) 


# Evaluate classifier's misclassification rate over entire training data
misclass_rate = np.sum(y_est != ytest) / float(len(y_est))

# Display classification results
import matplotlib.pyplot as plt
print('\nOverall misclassification rate: {0:.3f}'.format(misclass_rate))

f = figure();
class0_ids = np.nonzero(ytest==0)[0].tolist()
plot(class0_ids, y_est_prob[class0_ids], '.y')
class1_ids = np.nonzero(ytest==1)[0].tolist()
plot(class1_ids, y_est_prob[class1_ids], '.r')
xlabel('Data object (Patient)'); ylabel('Predicted prob. of chd');
legend(['Chd', 'no_Chd'])
ylim(-0.01,1.5)
plt.axhline(y=0.5, color='k', linestyle='--')

show()


# Import data

import numpy as np
import pandas as pd


# reading csv files
df =  pd.read_excel(r'C:\Users\olive\Documents\DTU\4. semester\Machine Learning and Data Mining\Project 2\dataset.xls')

#Making dummy varibales where needed
df = pd.get_dummies(df, columns=['famhist'])
df = df.drop(columns=['famhist_Absent','row'])
df = df.rename(columns={'famhist_Present': 'famhist'})

#Remove age variable from dataset
df.drop('age', inplace=True, axis=1)

#log transform of alcohol and tobacco
df['alcohol']=np.log(df['alcohol']+0.1)
df['tobacco']=np.log(df['tobacco']+0.01)

# Extract class names to python list,
# then encode with integers (dict)
classLabels = list(df['chd'])
classNames = ['noCHD','CHD']

# Extract vector y, convert to NumPy matrix and transpose
y = np.array(df.pop('chd'))

#Normalise all data if needed
def z_score_standardization(series):
    return (series - series.mean()) / series.std()
for col in df.columns:
    df[col] = z_score_standardization(df[col])


# Extract attribute names
attributeNames = list(df.columns)

# Preallocate memory, then extract data to matrix X
X = df.to_numpy()
np.shape(df)

# Compute values of N, M and C.
N = len(y)
M = len(attributeNames)
C = len(classNames)


#%% imports and helper functions
from sklearn import tree
import numpy as np
from sklearn import tree
from platform import system
from os import getcwd
from toolbox_02450 import windows_graphviz_call
import matplotlib.pyplot as plt
from matplotlib.image import imread
import sklearn
from sklearn import model_selection
from sklearn.model_selection import KFold

#Helper Functions
#Inner inner loop function
def innerloop_Error_val_CT(Xtrain,ytrain,Xtest,ytest):
    error_rates_inner = []
    for i in range(len(impurity_values)):
        #Define model with purity gain minimum value for splits.
        dtc = tree.DecisionTreeClassifier(criterion='gini', min_impurity_decrease=impurity_values[i])
        dtc = dtc.fit(Xtrain, ytrain)
        pred = dtc.predict(Xtest)
        error = 1-sklearn.metrics.accuracy_score(ytest,pred)
        error_rates_inner.append(error)
        
    return np.array(error_rates_inner)

import sklearn.linear_model as lin


#Helper Functions
#Inner inner loop function
def innerloop_Error_val_logist(Xtrain,ytrain,Xtest,ytest):
    error_rates_inner = []
    for i in range(len(lambda_values)):
        #Define model with purity gain minimum value for splits.
        lr = lin.LogisticRegression(penalty='l2',C=1/(lambda_values[i]+0.000000001))
        lr.fit(Xtrain, ytrain)
        pred = lr.predict(Xtest)
        error = 1-sklearn.metrics.accuracy_score(ytest,pred)
        error_rates_inner.append(error)
        
    return np.array(error_rates_inner)

#%% 2-fold-crossvalidation of the 3 models (settings)
#settings
K1=10
K2=10
test_proportion_inner = 0.3
total_acc = 0
total_prec = 0
total_recall = 0
total_spec =0
total_fscore =0


#Outher loop
#Classification Tree settings 
impurity_values = np.arange(0,0.0201,0.002)
Etest_list_CT = []
impurity_min_list = []

#Logistic regression
lambda_values = np.array([0,10**(-2),5*10**(-2),10**(-1),5*10**(-1),5,10,5*10,10**2,10**4])
Etest_list_logist = []
lambda_min_list = []

#Baseline
Etest_list_baseline = []

#corss validation fold
kf = KFold(n_splits=K1)
kf.get_n_splits(X)
i=0
for train_index, test_index in kf.split(X):
    i += 1

    Xpar, Xtest = X[train_index], X[test_index]
    ypar, ytest = y[train_index], y[test_index]
    
    #%%Inner loop Classification Tree    
    #first loopround of inner loop
    #corss validation fold
    kf2 = KFold(n_splits=K2)
    kf2.get_n_splits(Xpar)
    j=0
    for train_index, test_index in kf2.split(Xpar):
        j += 1
        Xtrain, Xval = X[train_index], X[test_index]
        ytrain, yval = y[train_index], y[test_index]
        
        #Inner Inner Loop over all min_impurity values (find the best complexity parameter)
        Errors_val = innerloop_Error_val_CT(Xtrain,ytrain,Xval,yval)
        if j == 1:
            Errors_val_all = Errors_val
        else:
            Errors_val_all = np.vstack((Errors_val_all,Errors_val))
    
    #Find the best value for the impurity minimum
    min_impurities_average_error = Errors_val_all.mean(axis=0)
    best_impurity_min = impurity_values[np.argmin(min_impurities_average_error)]
    
    #Fit the model
    dtc = tree.DecisionTreeClassifier(criterion='gini', min_impurity_decrease=best_impurity_min)
    dtc = dtc.fit(Xpar, ypar)
    
    #Test on the outer test set
    pred = dtc.predict(Xtest)
    Etest = 1-sklearn.metrics.accuracy_score(ytest,pred)
    
    #append results
    Etest_list_CT.append(Etest)
    impurity_min_list.append(best_impurity_min)

    
    #%%Inner loop logistic regression
   
    #first loopround of inner loop
    #corss validation fold
    kf3 = KFold(n_splits=K2)
    kf3.get_n_splits(Xpar)
    j=0
    for train_index, test_index in kf3.split(Xpar):
        j += 1
        Xtrain, Xval = X[train_index], X[test_index]
        ytrain, yval = y[train_index], y[test_index]
        
        #Inner Inner Loop over all min_impurity values (find the best complexity parameter)
        Errors_val = innerloop_Error_val_logist(Xtrain,ytrain,Xval,yval)
        if j == 1:
            Errors_val_all = Errors_val
        else:
            Errors_val_all = np.vstack((Errors_val_all,Errors_val))
    
    #Find the best value for the lambda minimum
    param_average_error = Errors_val_all.mean(axis=0)
    best_param = lambda_values[np.argmin(param_average_error)]
    
    #Fit the model withy the best parameter
    lr = lin.LogisticRegression(penalty='l2',C=1/(best_param+0.000000001))
    lr.fit(Xpar, ypar)
    
    #Test on the outer test set
    pred = lr.predict(Xtest)
    Etest = 1-sklearn.metrics.accuracy_score(ytest,pred)
    
    #append results
    Etest_list_logist.append(Etest)
    lambda_min_list.append(best_param)
    
      #Get the confusion matrix
    X_new = df.sample(frac=0.5)
    y_true =y[len(y)//2:]
    y_pred = lr.predict(X_new)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    #print('Confusion matrix for logistic regression')
    accuracy = (tp+tn)/(tp+tn+fp+fn)
    precision = tp/(tp+fp)
    recall = tp/(tp+fn)
    spec = tn/(tn+fp)
    fscore = 1/((1/precision)+(1/recall))
    total_acc += accuracy
    total_prec += precision
    total_recall += recall
    total_spec += spec
    total_fscore += fscore
    
    #%%Baseline
   
    #Find the most prevalent classification in the test data in order to classify all test data points as this
    if np.mean(ypar) <= 0.5:
        pred = np.zeros(len(ytest))
    else:
        pred = np.ones(len(ytest))
    
    #Test on the outer test set
    Etest = 1-sklearn.metrics.accuracy_score(ytest,pred)
    
    #append results
    Etest_list_baseline.append(Etest)

results = pd.DataFrame({'Min Impurity split':impurity_min_list,'Error_CT':Etest_list_CT, 
                           'lambda':lambda_min_list,'Error_logist':Etest_list_logist, 'Error_baseline': Etest_list_baseline})
    
  

results['Min Impurity split'].value_counts()
results['Error_CT'].mean()
results['lambda'].value_counts()
results['Error_logist'].mean()
results['Error_baseline'].mean()